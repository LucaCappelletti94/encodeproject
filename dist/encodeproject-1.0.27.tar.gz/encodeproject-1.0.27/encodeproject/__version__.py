"""Current version of package encodeproject"""
__version__ = "1.0.27"
